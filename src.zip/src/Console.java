class Console {
    public static void main(String[] args) {
        System.out.println("=== ConsoleUI ===");
        ConsoleUI ui = new ConsoleUI();
        ui.start();
    }    
}